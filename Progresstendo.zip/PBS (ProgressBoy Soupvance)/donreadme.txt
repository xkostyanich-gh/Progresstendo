я ленивый и все системы сырые соре :|

все планы систем на всякий:
Idlicom  v
PBES  v
ProgressBoy  v
ProgressBoy Soupvance  v
ProgressBoy Indigo x
Progresstendo 86 x
Progresstendo GIF x
Progresstendo 2GIF x
Progresstendo Svvitc x
Progresstendo Svvitc dva x